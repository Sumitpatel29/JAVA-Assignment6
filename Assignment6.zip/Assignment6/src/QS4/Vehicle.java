package QS4;

import java.util.Scanner;

public  class Vehicle
{
	String make;
	String model;
	int year;
	char fuelType;
	Scanner sc=new Scanner(System.in);
	
	double  fuelEfficiency() 
	{
		System.out.println("Enter MaxSpeed: ");
		int maxSpeed=sc.nextInt();
		System.out.println("Enter initial ODOMeter reading: ");
		int initOdo=sc.nextInt();
		System.out.println("Enter final ODOMeter reading: ");
		int finalOdo=sc.nextInt();
		
		double distanceTravelled= finalOdo-initOdo;
		double fuelefficiency =maxSpeed/distanceTravelled;
		
		return fuelefficiency;
		
	}
}
class Truck extends Vehicle
{
	
	
}
class Car extends Vehicle
{
	
}
class MotorCycle extends Vehicle
{
	
}

