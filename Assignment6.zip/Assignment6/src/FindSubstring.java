import java.util.Scanner;

public class FindSubstring {

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string: ");
		String str=sc.nextLine();
		System.out.println("Enter a sub-string to search: ");
		String search=sc.nextLine();
		
		int index=new StringBuilder(str).indexOf(search);
		System.out.println("The substrig is found at index: "+ index);
		sc.close();
	}

}
