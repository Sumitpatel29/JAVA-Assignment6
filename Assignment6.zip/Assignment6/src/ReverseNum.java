import java.util.Scanner;

public class ReverseNum {
	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a string to reverse: ");
		String str=sc.nextLine();
		String revStr=new StringBuilder(str).reverse().toString();
		System.out.println("The reversed string is: "+revStr);
		sc.close();
	}
}
